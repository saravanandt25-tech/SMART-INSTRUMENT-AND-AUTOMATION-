const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('#nav');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle.setAttribute('aria-expanded', 'false');
}));
document.querySelector('#year').textContent = new Date().getFullYear();
document.querySelector('#contactForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const name = document.querySelector('#name').value.trim();
  const company = document.querySelector('#company').value.trim();
  const interest = document.querySelector('#interest').value;
  const message = document.querySelector('#message').value.trim();
  const text = `Hello Smart Instrument and Automation,%0A%0AName: ${encodeURIComponent(name)}%0ACompany: ${encodeURIComponent(company || 'Not provided')}%0ARequirement: ${encodeURIComponent(interest)}%0AMessage: ${encodeURIComponent(message)}`;
  window.open(`https://wa.me/918680986443?text=${text}`, '_blank', 'noopener');
});