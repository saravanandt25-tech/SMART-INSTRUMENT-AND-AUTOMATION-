SMART INSTRUMENT AND AUTOMATION — WEBSITE STARTER
Files: index.html, style.css, script.js, logo.svg

PREVIEW:
Open index.html in a browser.

PUBLISH FOR FREE:
1. Create an account on GitHub.
2. Create a new public repository (example: smart-instrument-automation).
3. Upload all four files to the repository's main/root folder.
4. Open Settings → Pages.
5. Under Build and deployment, select Deploy from a branch, choose main and /(root), then Save.
6. GitHub will provide a public website URL after deployment.

IMPORTANT:
- The site is in English and responsive for mobile.
- The enquiry form opens WhatsApp to +91 86809 86443; it does not send email or store enquiries.
- Replace the logo.svg with a clean authorized company logo if you have a non-watermarked original.
- Add a company email address, exact business address, GST details and verified product/brand list before publishing, if applicable.
- A custom domain such as smartinstrumentautomation.com may require purchasing the domain separately.
